package com.policy.controller;

import com.policy.model.Policy;
import com.policy.service.PolicyService;
import com.policy.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PolicyController.class)
class PolicyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService mockUserservice;
    @MockBean
    private PolicyService mockPolicyservice;

    @Test
    void testRegisterPolicy() throws Exception {
        // Setup
        when(mockPolicyservice.setPolicyId("policyType")).thenReturn("policyId");
        when(mockPolicyservice.calculateEndDate(LocalDate.of(2020, 1, 1), 0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).thenReturn(LocalDate.of(2020, 1, 1));
        when(mockPolicyservice.calculateMaturityAmount(0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).thenReturn(0);

        // Configure PolicyService.addPolicy(...).
        final Policy policy = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        when(mockPolicyservice.addPolicy(
                eq(new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0)),
                any(HttpServletResponse.class))).thenReturn(policy);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/policies/register")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testRegisterPolicy_PolicyServiceAddPolicyThrowsIOException() throws Exception {
        // Setup
        when(mockPolicyservice.setPolicyId("policyType")).thenReturn("policyId");
        when(mockPolicyservice.calculateEndDate(LocalDate.of(2020, 1, 1), 0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).thenReturn(LocalDate.of(2020, 1, 1));
        when(mockPolicyservice.calculateMaturityAmount(0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).thenReturn(0);
        when(mockPolicyservice.addPolicy(
                eq(new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0)),
                any(HttpServletResponse.class))).thenThrow(IOException.class);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/policies/register")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testListOfPolicies() throws Exception {
        // Setup
        // Configure PolicyService.listPolicies(...).
        final List<Policy> policies = List.of(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));
        when(mockPolicyservice.listPolicies()).thenReturn(policies);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/getpolicieslist")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testListOfPolicies_PolicyServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockPolicyservice.listPolicies()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/getpolicieslist")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testSearchPolicies() throws Exception {
        // Setup
        // Configure UserService.getPolicies(...).
        final List<Policy> policies = List.of(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));
        when(mockUserservice.getPolicies("policyType")).thenReturn(policies);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/getpolicy")
                        .param("policyType", "policyType")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testSearchPolicies_UserServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockUserservice.getPolicies("policyType")).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/getpolicy")
                        .param("policyType", "policyType")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testSearchPolicies_ThrowsNoSuchElementException() throws Exception {
        // Setup
        // Configure UserService.getPolicies(...).
        final List<Policy> policies = List.of(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));
        when(mockUserservice.getPolicies("policyType")).thenReturn(policies);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/getpolicy")
                        .param("policyType", "policyType")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testPdfGeneration() throws Exception {
        // Setup
        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/pdf/{policyId}", "policyId")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
        verify(mockPolicyservice).generatePdf(any(HttpServletResponse.class), eq("policyId"));
    }

    @Test
    void testPdfGeneration_PolicyServiceThrowsIOException() throws Exception {
        // Setup
        doThrow(IOException.class).when(mockPolicyservice).generatePdf(any(HttpServletResponse.class), eq("policyId"));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/policies/pdf/{policyId}", "policyId")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
