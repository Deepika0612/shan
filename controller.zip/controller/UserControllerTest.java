package com.policy.controller;

import com.policy.model.Login;
import com.policy.model.User;
import com.policy.service.Impl.CustomerServiceImpl;
import com.policy.service.UserService;
import com.policy.util.JwtUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@ExtendWith(SpringExtension.class)
@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService mockUserservice;
    @MockBean
    private CustomerServiceImpl mockCustomerservice;
    @MockBean
    private JwtUtil mockJwtUtil;
    @MockBean
    private AuthenticationManager mockAuthenticationManager;

    @Test
    void testRegistration() throws Exception {
        // Setup
        // Configure UserService.saveUser(...).
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserservice.saveUser(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class))).thenReturn(user);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/auth/signup")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUserLogin() throws Exception {
        // Setup
        // Configure UserService.login(...).
        final Map<String, Object> stringObjectMap = Map.ofEntries(Map.entry("value", "value"));
        when(mockUserservice.login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class))).thenReturn(stringObjectMap);

        when(mockAuthenticationManager.authenticate(null)).thenReturn(null);
        when(mockCustomerservice.loadUserByUsername("userId")).thenReturn(null);
        when(mockJwtUtil.generateToken(any(UserDetails.class))).thenReturn("jwtToken");

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/auth/signin")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
        verify(mockUserservice).login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class));
        verify(mockAuthenticationManager).authenticate(null);
    }

    @Test
    void testUserLogin_AuthenticationManagerThrowsAuthenticationException() throws Exception {
        // Setup
        // Configure UserService.login(...).
        final Map<String, Object> stringObjectMap = Map.ofEntries(Map.entry("value", "value"));
        when(mockUserservice.login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class))).thenReturn(stringObjectMap);

        when(mockAuthenticationManager.authenticate(null)).thenThrow(AuthenticationException.class);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/auth/signin")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
        verify(mockUserservice).login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class));
    }

    @Test
    void testUserLogin_CustomerServiceImplThrowsUsernameNotFoundException() throws Exception {
        // Setup
        // Configure UserService.login(...).
        final Map<String, Object> stringObjectMap = Map.ofEntries(Map.entry("value", "value"));
        when(mockUserservice.login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class))).thenReturn(stringObjectMap);

        when(mockAuthenticationManager.authenticate(null)).thenReturn(null);
        when(mockCustomerservice.loadUserByUsername("userId")).thenThrow(UsernameNotFoundException.class);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/auth/signin")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
        verify(mockUserservice).login(
                eq(new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password")), any(Login.class));
        verify(mockAuthenticationManager).authenticate(null);
    }
}
