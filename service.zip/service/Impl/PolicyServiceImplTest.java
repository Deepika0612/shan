package com.policy.service.Impl;

import com.policy.model.Policy;
import com.policy.repo.PolicyRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PolicyServiceImplTest {

    @Mock
    private PolicyRepo mockAdminrepo;

    private PolicyServiceImpl policyServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        policyServiceImplUnderTest = new PolicyServiceImpl(mockAdminrepo);
    }

    @Test
    void testAddPolicy() throws Exception {
        // Setup
        final Policy admin = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        final HttpServletResponse response = new MockHttpServletResponse();
        final Policy expectedResult = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);

        // Configure PolicyRepo.save(...).
        final Policy policy = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        when(mockAdminrepo.save(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).thenReturn(policy);

        // Run the test
        final Policy result = policyServiceImplUnderTest.addPolicy(admin, response);

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    void testAddPolicy_PolicyRepoThrowsOptimisticLockingFailureException() {
        // Setup
        final Policy admin = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        final HttpServletResponse response = new MockHttpServletResponse();
        when(mockAdminrepo.save(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0)))
                .thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> policyServiceImplUnderTest.addPolicy(admin, response))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }

    @Test
    void testListPolicies() {
        // Setup
        final List<Policy> expectedResult = Arrays.asList(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));

        // Configure PolicyRepo.findAll(...).
        final List<Policy> policies = Arrays.asList(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));
        when(mockAdminrepo.findAll()).thenReturn(policies);

        // Run the test
        final List<Policy> result = policyServiceImplUnderTest.listPolicies();

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    void testListPolicies_PolicyRepoReturnsNoItems() {
        // Setup
        when(mockAdminrepo.findAll()).thenReturn(Collections.emptyList());

        // Run the test
        final List<Policy> result = policyServiceImplUnderTest.listPolicies();

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testSetPolicyId() {
        assertThat(policyServiceImplUnderTest.setPolicyId("value")).isEqualTo("result");
    }

    @Test
    void testCalculateEndDate() {
        assertThat(policyServiceImplUnderTest.calculateEndDate(LocalDate.of(2020, 1, 1), 0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).isEqualTo(LocalDate.of(2020, 1, 1));
    }

    @Test
    void testCalculateMaturityAmount() {
        assertThat(policyServiceImplUnderTest.calculateMaturityAmount(0,
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0))).isEqualTo(0);
    }

    @Test
    void testGeneratePdf() throws Exception {
        // Setup
        final HttpServletResponse response = new MockHttpServletResponse();

        // Configure PolicyRepo.getPoliciesDocument(...).
        final Policy policy = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        when(mockAdminrepo.getPoliciesDocument("policyId")).thenReturn(policy);

        // Run the test
        policyServiceImplUnderTest.generatePdf(response, "policyId");

        // Verify the results
    }

    @Test
    void testGeneratePdf_ThrowsIOException() {
        // Setup
        final HttpServletResponse response = new MockHttpServletResponse();

        // Configure PolicyRepo.getPoliciesDocument(...).
        final Policy policy = new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0,
                "policyType", "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0);
        when(mockAdminrepo.getPoliciesDocument("policyId")).thenReturn(policy);

        // Run the test
        assertThatThrownBy(() -> policyServiceImplUnderTest.generatePdf(response, "policyId"))
                .isInstanceOf(IOException.class);
    }
}
