package com.policy.service.Impl;

import com.policy.model.Login;
import com.policy.model.Policy;
import com.policy.model.User;
import com.policy.repo.PolicyRepo;
import com.policy.repo.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepo mockUserrepo;
    @Mock
    private PolicyRepo mockAdminrepo;
    @Mock
    private JavaMailSender mockMailSender;
    @Mock
    private PasswordEncoder mockPasswordEncoder;

    private UserServiceImpl userServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        userServiceImplUnderTest = new UserServiceImpl(mockUserrepo, mockAdminrepo, mockMailSender,
                mockPasswordEncoder);
    }

    @Test
    void testSaveUser() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        final User expectedResult = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockPasswordEncoder.encode("rawPassword")).thenReturn("result");

        // Configure UserRepo.findByUserId(...).
        final User user1 = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserrepo.findByUserId("userId")).thenReturn(user1);

        // Configure UserRepo.save(...).
        final User user2 = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserrepo.save(
                new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password"))).thenReturn(user2);

        // Run the test
        final User result = userServiceImplUnderTest.saveUser(user, l);

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
        verify(mockMailSender).send(new SimpleMailMessage());
    }

    @Test
    void testSaveUser_JavaMailSenderThrowsMailException() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        doThrow(MailException.class).when(mockMailSender).send(new SimpleMailMessage());

        // Run the test
        assertThatThrownBy(() -> userServiceImplUnderTest.saveUser(user, l)).isInstanceOf(MailException.class);
    }

    @Test
    void testSaveUser_UserRepoFindByUserIdReturnsNull() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        final User expectedResult = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockPasswordEncoder.encode("rawPassword")).thenReturn("result");
        when(mockUserrepo.findByUserId("userId")).thenReturn(null);

        // Configure UserRepo.save(...).
        final User user1 = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserrepo.save(
                new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password"))).thenReturn(user1);

        // Run the test
        final User result = userServiceImplUnderTest.saveUser(user, l);

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
        verify(mockMailSender).send(new SimpleMailMessage());
    }

    @Test
    void testSaveUser_UserRepoSaveThrowsOptimisticLockingFailureException() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        when(mockPasswordEncoder.encode("rawPassword")).thenReturn("result");

        // Configure UserRepo.findByUserId(...).
        final User user1 = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserrepo.findByUserId("userId")).thenReturn(user1);

        when(mockUserrepo.save(
                new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password"))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> userServiceImplUnderTest.saveUser(user, l))
                .isInstanceOf(OptimisticLockingFailureException.class);
        verify(mockMailSender).send(new SimpleMailMessage());
    }

    @Test
    void testUserType() {
        assertThat(userServiceImplUnderTest.userType(0,
                new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo", LocalDate.of(2020, 1, 1),
                        "qualification", "company", "gender", 0, "employerType", "employerName", "role", "userId",
                        "password"))).isEqualTo("userId");
    }

    @Test
    void testPasswordGeneration() {
        // Setup
        final User u = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockPasswordEncoder.encode("rawPassword")).thenReturn("result");

        // Run the test
        final String result = userServiceImplUnderTest.passwordGeneration(u, "subject");

        // Verify the results
        assertThat(result).isEqualTo("result");
        verify(mockMailSender).send(new SimpleMailMessage());
    }

    @Test
    void testPasswordGeneration_JavaMailSenderThrowsMailException() {
        // Setup
        final User u = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        doThrow(MailException.class).when(mockMailSender).send(new SimpleMailMessage());

        // Run the test
        assertThatThrownBy(() -> userServiceImplUnderTest.passwordGeneration(u, "subject"))
                .isInstanceOf(MailException.class);
    }

    @Test
    void testLogin() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        // Configure UserRepo.findByUserId(...).
        final User user1 = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockUserrepo.findByUserId("userId")).thenReturn(user1);

        // Run the test
        final Map<String, Object> result = userServiceImplUnderTest.login(user, l);

        // Verify the results
    }

    @Test
    void testLogin_UserRepoReturnsNull() {
        // Setup
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        final Login l = new Login();
        l.setUserId("userId");
        l.setPassword("password");

        when(mockUserrepo.findByUserId("userId")).thenReturn(null);

        // Run the test
        final Map<String, Object> result = userServiceImplUnderTest.login(user, l);

        // Verify the results
    }

    @Test
    void testGetPolicies() {
        // Setup
        final List<Policy> expectedResult = Arrays.asList(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));

        // Configure PolicyRepo.findPolicy(...).
        final List<Policy> policies = Arrays.asList(
                new Policy("policyId", "policyName", LocalDate.of(2020, 1, 1), 0, "company", 0, "policyType",
                        "userType", 2020, 0, 0, LocalDate.of(2020, 1, 1), 0));
        when(mockAdminrepo.findPolicy("policyType")).thenReturn(policies);

        // Run the test
        final List<Policy> result = userServiceImplUnderTest.getPolicies("policyType");

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    void testGetPolicies_PolicyRepoReturnsNoItems() {
        // Setup
        when(mockAdminrepo.findPolicy("policyType")).thenReturn(Collections.emptyList());

        // Run the test
        final List<Policy> result = userServiceImplUnderTest.getPolicies("policyType");

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }
}
