package com.policy.service.Impl;

import com.policy.model.User;
import com.policy.repo.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private UserRepo mockRepository;

    private CustomerServiceImpl customerServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        customerServiceImplUnderTest = new CustomerServiceImpl(mockRepository);
    }

    @Test
    void testLoadUserByUsername() {
        // Setup
        // Configure UserRepo.findByUserId(...).
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockRepository.findByUserId("userId")).thenReturn(user);

        // Run the test
        final UserDetails result = customerServiceImplUnderTest.loadUserByUsername("userId");

        // Verify the results
    }

    @Test
    void testLoadUserByUsername_ThrowsUsernameNotFoundException() {
        // Setup
        // Configure UserRepo.findByUserId(...).
        final User user = new User(0L, "firstName", "lastName", "emailAddress", "address", "panNo",
                LocalDate.of(2020, 1, 1), "qualification", "company", "gender", 0, "employerType", "employerName",
                "role", "userId", "password");
        when(mockRepository.findByUserId("userId")).thenReturn(user);

        // Run the test
        assertThatThrownBy(() -> customerServiceImplUnderTest.loadUserByUsername("userId"))
                .isInstanceOf(UsernameNotFoundException.class);
    }
}
